
package jardinbotanico;

import java.util.ArrayList;
import java.util.List;


public class Jardin {
    
    private List<Planta> plantas = new ArrayList<>();
    
    public Jardin()
    {
        
    }
    
    public void agregarPlanta(Planta planta)
    {
        if(planta == null)
        {
            throw new NullPointerException("Error. Esto no es una planta, es null.");
        }
        if(plantas.contains(planta))
        {
            throw new PlantaRepetidaException();
        }
        plantas.add(planta);
        
    }
    
    public void mostrarPlantas()
    {
        for(Planta planta : plantas)
        {
            System.out.println(planta.toString());
        }
    }
    
    public void podarPlantas()
    {
        for(Planta planta : plantas)
        {
            if(planta instanceof Flor)
            {
                System.out.println("Esa planta no requiere poda.");
            }
            else
            {
                planta.podar();
            }
        }
    }
}
