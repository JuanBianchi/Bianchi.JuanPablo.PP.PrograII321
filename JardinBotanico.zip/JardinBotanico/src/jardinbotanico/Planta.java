
package jardinbotanico;

import java.util.Objects;


public abstract class Planta implements Podable{
    
    private String nombre;
    private String ubicacion;
    private String clima;
    
    public Planta(String nombre, String ubicacion, String clima)
    {
        this.nombre = nombre;
        this.ubicacion = ubicacion;
        this.clima = clima;
    }
    
    
    @Override
    public String toString() {
        return "Nombre: " + nombre + ", Ubicacion: " + ubicacion + ", Clima: " + clima;
    }
    
    @Override
    public boolean equals(Object o)
    {
        if(this == o)
        {
            return true;
        }
        if(o == null || getClass() != o.getClass())
        {
            return false;
        }
        Planta p =(Planta) o;
        
        return p.nombre.equals(this.nombre) && p.ubicacion.equals(this.ubicacion);
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 19 * hash + Objects.hashCode(this.nombre);
        hash = 19 * hash + Objects.hashCode(this.ubicacion);
        return hash;
    }
    
}
