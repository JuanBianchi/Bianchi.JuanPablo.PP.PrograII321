
package jardinbotanico;

public class JardinBotanico {

    public static void main(String[] args) {
        
        
        Jardin jardinBotanico = new Jardin();
        
        Arbol arbol1 = new Arbol("roble", "norte", "humedo", 70);
        Arbol arbol2 = new Arbol("roble", "norte", "arido", 80);
        Arbol arbol3 = new Arbol("Abeto", "sur", "humedo", 20);
        Arbol arbol4 = new Arbol("Abeto", "norte", "humedo", 15);
        Arbusto arbusto1 = new Arbusto("Sorzal", "sur", "arido", 9);
        
        Flor flor1 = new Flor("Jazmin", "sur", "templado", Temporada.PRIMAVERA);
        Flor flor2 = new Flor("rosa", "sur", "templado", Temporada.PRIMAVERA);
        Flor flor3 = new Flor("tulipan", "sur", "templado", Temporada.OTONIO);
        Flor flor4 = new Flor("rosa", "sur", "templado", Temporada.PRIMAVERA);
        
        try{
            jardinBotanico.agregarPlanta(arbol1);
            jardinBotanico.agregarPlanta(arbol3);
            jardinBotanico.agregarPlanta(arbol4);
            jardinBotanico.agregarPlanta(flor1);
            jardinBotanico.agregarPlanta(flor2);
            jardinBotanico.agregarPlanta(flor3);
            //ardinBotanico.agregarPlanta(flor4); REPETIDA
            jardinBotanico.agregarPlanta(arbusto1);
            //jardinBotanico.agregarPlanta(arbol2); REPETIDA
        }
        catch(NullPointerException e)
        {
            System.out.println(e.getMessage());
        }
        catch(PlantaRepetidaException ex)
        {
            System.out.println(ex.getMessage());
        }
        
        jardinBotanico.mostrarPlantas();
        System.out.println("------------");
        
        
        jardinBotanico.podarPlantas();
        
        
    }
    
}
