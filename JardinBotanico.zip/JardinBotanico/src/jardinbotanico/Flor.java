
package jardinbotanico;


public class Flor extends Planta{
    
    private Temporada epocaFlorecimiento;
    
    public Flor(String nombre, String ubicacion, String clima, Temporada epocaFlorecimiento)
    {
        super(nombre, ubicacion, clima);
        this.epocaFlorecimiento = epocaFlorecimiento;
    }
    
    @Override
    public void podar()
    {
        System.out.println("No requiere poda.");
    }
    
    
    @Override
    public String toString() {
        return super.toString() + ", Epoca de florecimiento: " + epocaFlorecimiento;
    }
    
    
}
