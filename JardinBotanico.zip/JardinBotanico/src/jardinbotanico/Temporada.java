
package jardinbotanico;


public enum Temporada {
    VERANO,
    INVIERNO,
    OTONIO,
    PRIMAVERA;
}
