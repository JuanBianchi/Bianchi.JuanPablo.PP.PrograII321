
package jardinbotanico;


public class Arbusto extends Planta{

    private static final int DENSIDAD_MAX = 10;
    private static final int DENSIDAD_MIN = 1;
    private int densidadFollaje;
    
    public Arbusto(String nombre, String ubicacion, String clima, int densidadFollaje)
    {
        super(nombre, ubicacion, clima);
        this.densidadFollaje = densidadFollaje;
    }
    
    @Override
    public void podar()
    {
        System.out.println("El arbusto fue podado.");
    }
    
    @Override
    public String toString() {
        return super.toString() + ", Densidad follaje: " + densidadFollaje;
    }
}
